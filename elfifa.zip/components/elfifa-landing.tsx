'use client'

import {
  ArrowRight,
  Award,
  BedDouble,
  Bus,
  Check,
  ChevronRight,
  CircleUserRound,
  Clock3,
  Facebook,
  FileText,
  Hotel,
  Instagram,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  PackageCheck,
  Phone,
  Plane,
  Play,
  QrCode,
  ShieldCheck,
  Star,
  Ticket,
  UserRound,
  UsersRound,
  Utensils,
  Video,
  X,
  Youtube,
} from 'lucide-react'
import { useState } from 'react'

const teal = '#007a82'
const gold = '#d9923b'

const facilities = [
  [PackageCheck, 'Perlengkapan'], [QrCode, 'Visa'], [Ticket, 'Tiket PP'], [UserRound, 'Mutawwif'],
  [Utensils, 'Konsumsi'], [Hotel, 'Hotel'], [Bus, 'Bus AC'], [Video, 'Dokumentasi'],
] as const

const gallery = [
  ['https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=800&q=80', 'Masjidil Haram'],
  ['https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e?auto=format&fit=crop&w=800&q=80', 'Jamaah Elfifa'],
  ['https://images.unsplash.com/photo-1564769625905-50e93615e769?auto=format&fit=crop&w=800&q=80', 'Arsitektur Islam'],
  ['https://images.unsplash.com/photo-1519817650390-64a93db51149?auto=format&fit=crop&w=800&q=80', 'Perjalanan Ibadah'],
  ['https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=800&q=80', 'Madinah'],
  ['https://images.unsplash.com/photo-1580418827493-f2b22c0a76cb?auto=format&fit=crop&w=800&q=80', 'Kota Suci'],
  ['https://images.unsplash.com/photo-1565552645632-d725f8bfc19a?auto=format&fit=crop&w=800&q=80', 'Kebersamaan'],
  ['https://images.unsplash.com/photo-1542816417-0983c9c9ad53?auto=format&fit=crop&w=800&q=80', 'Momen Berharga'],
]

const articles = [
  ['https://images.unsplash.com/photo-1577083552431-6e5fd01aa342?auto=format&fit=crop&w=900&q=80', 'Tips', '12 Des 2024', 'Persiapan Fisik Sebelum Berangkat Umroh', 'Bekali diri dengan persiapan yang matang agar ibadah berjalan lebih khusyuk dan nyaman.'],
  ['https://images.unsplash.com/photo-1519817650390-64a93db51149?auto=format&fit=crop&w=900&q=80', 'Panduan', '08 Des 2024', 'Panduan Memilih Paket Umroh Terbaik', 'Kenali hal-hal penting yang perlu diperhatikan sebelum memilih travel umroh.'],
  ['https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=900&q=80', 'Update', '01 Des 2024', 'Keutamaan Bulan Rajab untuk Umroh', 'Temukan keberkahan perjalanan spiritual di bulan yang penuh kemuliaan.'],
]

function Logo() {
  return <a href="#beranda" className="flex items-center gap-3" aria-label="Elfifa home">
    <span className="grid size-11 place-items-center rounded-xl bg-[#007a82] text-white shadow-lg shadow-[#007a82]/20"><KaabaIcon /></span>
    <span><span className="block text-xl font-black tracking-tight text-[#007a82]">elfifa</span><span className="block text-[9px] font-semibold uppercase tracking-[0.14em] text-slate-400">Umroh Praktis Full Service</span></span>
  </a>
}

function KaabaIcon() { return <svg viewBox="0 0 32 32" className="size-6" fill="none" aria-hidden="true"><path d="M5 11.5 16 6l11 5.5v12L16 29 5 23.5v-12Z" fill="currentColor" opacity=".2"/><path d="M5 11.5 16 6l11 5.5v12L16 29 5 23.5v-12Z" stroke="currentColor" strokeWidth="1.7"/><path d="M5.5 14.3 16 19.5l10.5-5.2M16 19.5V29M9 9.2v14.5M23 9.2v14.5" stroke="currentColor" strokeWidth="1.4"/><path d="M9 14h14v3H9z" fill="currentColor"/></svg> }

export default function ElfifaLanding() {
  const [menuOpen, setMenuOpen] = useState(false)
  return <div className="min-h-screen bg-white text-slate-800 selection:bg-[#d9923b]/20 selection:text-[#007a82]">
    <header className="sticky top-0 z-50 border-b border-slate-100/80 bg-white/90 backdrop-blur-xl">
      <div className="mx-auto flex h-[76px] max-w-7xl items-center justify-between px-5 lg:px-8"><Logo />
        <nav className="hidden items-center gap-8 md:flex" aria-label="Navigasi utama">{['Beranda','Profil','Paket','Galeri','Berita'].map((item, i) => <a key={item} href={['#beranda','#profil','#paket','#galeri','#berita'][i]} className="text-sm font-medium text-slate-600 transition-colors hover:text-[#007a82]">{item}</a>)}</nav>
        <a href="#kontak" className="hidden items-center gap-2 rounded-full bg-[#d9923b] px-5 py-3 text-sm font-bold text-white shadow-lg shadow-[#d9923b]/20 transition-transform hover:-translate-y-0.5 sm:flex">Hubungi Kami <ArrowRight className="size-4" /></a>
        <button className="rounded-lg p-2 text-[#007a82] md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Tutup menu' : 'Buka menu'}>{menuOpen ? <X /> : <Menu />}</button>
      </div>
      {menuOpen && <nav className="border-t border-slate-100 bg-white px-5 py-4 md:hidden">{['Beranda','Profil','Paket','Galeri','Berita'].map((item, i) => <a onClick={() => setMenuOpen(false)} key={item} href={['#beranda','#profil','#paket','#galeri','#berita'][i]} className="block border-b border-slate-100 py-3 text-sm font-semibold text-slate-600 last:border-0">{item}</a>)}</nav>}
    </header>

    <main>
      <section id="beranda" className="relative isolate overflow-hidden bg-[#f3f8f7]">
        <div className="absolute inset-0 -z-10 bg-[linear-gradient(90deg,rgba(243,248,247,.98)_0%,rgba(243,248,247,.9)_38%,rgba(243,248,247,.45)_100%),url('https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e?auto=format&fit=crop&w=2200&q=85')] bg-cover bg-center" />
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-20 lg:grid-cols-[1.05fr_.95fr] lg:px-8 lg:py-28">
          <div className="max-w-2xl"><span className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#d9923b]/30 bg-[#d9923b]/10 px-4 py-2 text-xs font-bold text-[#b56d1d]"><span className="size-2 animate-pulse rounded-full bg-[#d9923b]" /> Pendaftaran Terbuka!</span><h1 className="text-balance text-5xl font-black leading-[1.05] tracking-[-0.04em] text-slate-900 sm:text-6xl lg:text-7xl">Wujudkan Niat Suci <span className="text-[#007a82]">Bersama Elfifa</span></h1><p className="mt-6 max-w-lg text-lg leading-8 text-slate-600">Perjalanan ibadah umroh 17 hari yang nyaman, aman, dan penuh makna. Temani langkah suci Anda dengan layanan full service terbaik.</p><div className="mt-9 flex flex-col gap-3 sm:flex-row"><a href="#paket" className="inline-flex items-center justify-center gap-2 rounded-full bg-[#007a82] px-6 py-3.5 font-bold text-white shadow-xl shadow-[#007a82]/20 transition-transform hover:-translate-y-1">Lihat Paket Promo <ArrowRight className="size-4" /></a><a href="https://wa.me/628123456789" className="inline-flex items-center justify-center gap-2 rounded-full border-2 border-[#007a82] px-6 py-3.5 font-bold text-[#007a82] transition-colors hover:bg-[#007a82] hover:text-white"><MessageCircle className="size-4" /> Konsultasi Gratis</a></div><div className="mt-10 flex items-center gap-5 text-sm text-slate-500"><div className="flex -space-x-2">{['https://i.pravatar.cc/80?img=47','https://i.pravatar.cc/80?img=12','https://i.pravatar.cc/80?img=32'].map((src) => <img key={src} src={src} alt="Jamaah Elfifa" className="size-9 rounded-full border-2 border-white object-cover" />)}</div><span><strong className="text-slate-800">2.000+</strong> jamaah telah berangkat</span></div></div>
          <div className="relative hidden lg:block"><div className="absolute -left-8 -top-8 size-28 rounded-full border border-[#d9923b]/30" /><div className="absolute -bottom-7 -right-5 size-40 rounded-full bg-[#d9923b]/10" /><div className="relative overflow-hidden rounded-[2rem] border-[10px] border-white bg-white shadow-2xl shadow-slate-900/20"><img src="https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=1100&q=85" alt="Pemandangan Masjidil Haram" className="aspect-[4/5] w-full object-cover" /><div className="absolute bottom-6 left-6 right-6 flex items-center justify-between rounded-2xl bg-white/95 p-4 shadow-xl"><div><p className="text-xs font-semibold text-slate-400">Keberangkatan terdekat</p><p className="mt-1 font-bold text-slate-800">Januari 2025</p></div><span className="grid size-10 place-items-center rounded-xl bg-[#d9923b]/15 text-[#d9923b]"><CalendarIcon /></span></div></div></div>
        </div>
      </section>

      <section id="profil" className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28"><div className="mx-auto max-w-2xl text-center"><p className="text-sm font-bold uppercase tracking-[0.2em] text-[#d9923b]">Tentang Kami</p><h2 className="mt-3 text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">Mengenal Elfifa Lebih Dekat</h2><p className="mt-4 leading-7 text-slate-500">Kami hadir untuk membantu Anda menunaikan ibadah umroh dengan tenang, nyaman, dan penuh kekhusyukan.</p></div><div className="group relative mx-auto mt-12 max-w-5xl overflow-hidden rounded-3xl bg-slate-900 shadow-2xl"><img src="https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=1600&q=80" alt="Suasana perjalanan umroh" className="aspect-video w-full object-cover opacity-60 transition-all duration-700 group-hover:scale-105" /><div className="absolute inset-0 bg-slate-950/20" /><button className="absolute left-1/2 top-1/2 grid size-20 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-[#d9923b] text-white shadow-2xl shadow-[#d9923b]/40 transition-transform hover:scale-110" aria-label="Putar video profil"><Play className="ml-1 size-8 fill-current" /></button><div className="absolute bottom-5 left-5 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-white/80"><Video className="size-4" /> Elfifa travel story</div></div></section>

      <section id="paket" className="bg-slate-50 px-5 py-20 lg:px-8 lg:py-28"><div className="mx-auto max-w-7xl"><div className="mb-10 flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="text-sm font-bold uppercase tracking-[0.2em] text-[#d9923b]">Pilihan Terbaik</p><h2 className="mt-2 text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">Paket Umroh Unggulan</h2></div><p className="max-w-sm text-sm leading-6 text-slate-500">Semua yang Anda butuhkan untuk perjalanan ibadah yang nyaman telah kami siapkan.</p></div><div className="grid overflow-hidden rounded-[2rem] bg-white shadow-2xl shadow-slate-200/80 md:grid-cols-[.8fr_1.2fr]"><div className="bg-[#eef4f3] p-7 sm:p-10"><span className="rounded-full bg-[#d9923b] px-3 py-1.5 text-[10px] font-black tracking-widest text-white">PROMO TERBATAS</span><h3 className="mt-7 text-2xl font-black text-slate-900">Umrah 17 Hari</h3><p className="mt-8 text-sm text-slate-400 line-through">Rp 42.900.000</p><p className="mt-1 text-5xl font-black tracking-tight text-[#007a82]">Rp 39,9 Jt</p><div className="mt-7 rounded-2xl border border-[#d9923b]/30 bg-[#d9923b]/10 p-4"><p className="text-xs font-bold uppercase tracking-wider text-[#b56d1d]">Penawaran spesial</p><p className="mt-1 text-xl font-black text-[#b56d1d]">DP Hanya 5 Juta!</p></div><div className="mt-10 hidden items-center gap-3 text-sm text-slate-500 md:flex"><ShieldCheck className="size-5 text-[#007a82]" /> Terdaftar & berizin resmi</div></div><div className="p-7 sm:p-10"><div className="flex items-start gap-4 border-b border-slate-100 pb-7"><span className="grid size-11 shrink-0 place-items-center rounded-xl bg-[#007a82]/10 text-[#007a82]"><Plane className="size-5" /></span><div><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Penerbangan</p><p className="mt-1 font-bold text-slate-800">Terbang Tanpa Transit <span className="font-normal text-slate-500">(SUB-JED | MED-SUB)</span></p></div></div><div className="grid gap-5 border-b border-slate-100 py-7 sm:grid-cols-2"><div><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Hotel Makkah</p><p className="mt-2 font-bold text-slate-800">Ghalib</p><div className="mt-1 flex items-center gap-2 text-xs text-slate-500"><span className="flex text-[#d9923b]">{[1,2,3].map(i => <Star key={i} className="size-3 fill-current" />)}</span> 250m dari masjid</div></div><div><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Hotel Madinah</p><p className="mt-2 font-bold text-slate-800">Royal Andalus</p><div className="mt-1 flex items-center gap-2 text-xs text-slate-500"><span className="flex text-[#d9923b]">{[1,2,3,4].map(i => <Star key={i} className="size-3 fill-current" />)}</span> 0m dari masjid</div></div></div><div className="py-7"><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Bonus & Fasilitas Gratis</p><div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">{['Percetakan Alquran','Jabal Magnet','Kuliner Arab','Ziarah Thaif','Albaik'].map(x => <div key={x} className="flex items-center gap-2 text-sm text-slate-600"><span className="grid size-5 shrink-0 place-items-center rounded-full bg-emerald-100 text-emerald-600"><Check className="size-3" /></span>{x}</div>)}</div></div><a href="https://wa.me/628123456789" className="flex items-center justify-center gap-2 rounded-xl bg-[#d9923b] px-5 py-4 text-center font-black text-white shadow-lg shadow-[#d9923b]/20 transition-transform hover:-translate-y-0.5">Daftar Sekarang - Seat Terbatas! <ChevronRight className="size-5" /></a></div></div></div></section>

      <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8"><div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">{facilities.map(([Icon, label]) => <div key={label} className="group flex flex-col items-center gap-3 rounded-2xl border border-slate-100 bg-white px-2 py-5 text-center transition-all hover:-translate-y-1 hover:border-[#007a82]/30 hover:shadow-lg"><span className="grid size-11 place-items-center rounded-xl bg-[#007a82]/8 text-[#007a82] transition-colors group-hover:bg-[#007a82] group-hover:text-white"><Icon className="size-5" /></span><span className="text-xs font-semibold text-slate-600">{label}</span></div>)}</div></section>

      <section id="galeri" className="bg-slate-50 px-5 py-20 lg:px-8 lg:py-28"><div className="mx-auto max-w-7xl"><div className="flex items-end justify-between"><div><p className="text-sm font-bold uppercase tracking-[0.2em] text-[#d9923b]">Momen Penuh Makna</p><h2 className="mt-2 text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">Galeri Kegiatan Jamaah</h2></div><a href="#kontak" className="hidden items-center gap-1 text-sm font-bold text-[#007a82] sm:flex">Lihat Galeri <ArrowRight className="size-4" /></a></div><div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-4">{gallery.map(([src, alt]) => <div key={alt} className="group aspect-square overflow-hidden rounded-2xl"><img src={src} alt={alt} className="size-full object-cover transition duration-500 group-hover:scale-110" /></div>)}</div></div></section>

      <section id="berita" className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28"><div className="flex items-end justify-between"><div><p className="text-sm font-bold uppercase tracking-[0.2em] text-[#d9923b]">Wawasan Perjalanan</p><h2 className="mt-2 text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">Berita & Artikel</h2></div><a href="#berita" className="hidden items-center gap-1 text-sm font-bold text-[#007a82] sm:flex">Lihat Semua <ArrowRight className="size-4" /></a></div><div className="mt-10 grid gap-7 md:grid-cols-3">{articles.map(([src, category, date, title, excerpt]) => <article key={title} className="group overflow-hidden rounded-2xl border border-slate-100 bg-white transition-all hover:-translate-y-1 hover:shadow-xl"><div className="aspect-[1.6] overflow-hidden"><img src={src} alt={title} className="size-full object-cover transition duration-500 group-hover:scale-105" /></div><div className="p-5"><div className="flex items-center justify-between"><span className="rounded-full bg-[#007a82]/10 px-3 py-1 text-[10px] font-black uppercase tracking-wider text-[#007a82]">{category}</span><span className="text-xs text-slate-400">{date}</span></div><h3 className="mt-4 text-lg font-black leading-snug text-slate-800">{title}</h3><p className="mt-2 text-sm leading-6 text-slate-500">{excerpt}</p><a href="#berita" className="mt-5 inline-flex items-center gap-1 text-sm font-bold text-[#007a82]">Baca Selengkapnya <ChevronRight className="size-4" /></a></div></article>)}</div></section>
    </main>

    <footer id="kontak" className="bg-[#102c2e] px-5 pb-6 pt-16 text-white lg:px-8"><div className="mx-auto max-w-7xl"><div className="grid gap-12 md:grid-cols-[1.3fr_.7fr_1fr]"><div><div className="flex items-center gap-3"><span className="grid size-11 place-items-center rounded-xl bg-[#d9923b] text-white"><KaabaIcon /></span><span className="text-2xl font-black">elfifa</span></div><p className="mt-5 max-w-xs text-sm leading-7 text-slate-300">Menemani perjalanan suci Anda menuju Baitullah dengan pelayanan sepenuh hati.</p><div className="mt-6 flex gap-3"><a href="#kontak" aria-label="Instagram" className="grid size-9 place-items-center rounded-full bg-white/10 transition-colors hover:bg-[#d9923b]"><Instagram className="size-4" /></a><a href="#kontak" aria-label="Facebook" className="grid size-9 place-items-center rounded-full bg-white/10 transition-colors hover:bg-[#d9923b]"><Facebook className="size-4" /></a><a href="#kontak" aria-label="Youtube" className="grid size-9 place-items-center rounded-full bg-white/10 transition-colors hover:bg-[#d9923b]"><Youtube className="size-4" /></a></div></div><div><h3 className="font-bold">Tautan Cepat</h3><div className="mt-5 flex flex-col gap-3 text-sm text-slate-300"><a href="#profil" className="transition-colors hover:text-[#d9923b]">Profil Elfifa</a><a href="#paket" className="transition-colors hover:text-[#d9923b]">Paket Umroh</a><a href="#galeri" className="transition-colors hover:text-[#d9923b]">Galeri Jamaah</a><a href="#berita" className="transition-colors hover:text-[#d9923b]">Artikel & Berita</a></div></div><div><h3 className="font-bold">Hubungi Kami</h3><div className="mt-5 flex flex-col gap-4 text-sm text-slate-300"><p className="flex gap-3"><MapPin className="mt-0.5 size-4 shrink-0 text-[#d9923b]" />Jl. Raya Jemursari No. 42, Surabaya</p><p className="flex gap-3"><Phone className="size-4 shrink-0 text-[#d9923b]" />+62 812-3456-789</p><p className="flex gap-3"><Mail className="size-4 shrink-0 text-[#d9923b]" />halo@elfifa.id</p></div></div></div><div className="mt-14 border-t border-white/10 pt-6 text-center text-xs text-slate-400">© 2025 Elfifa Travel. Semua hak dilindungi.</div></div></footer>
    <a href="https://wa.me/628123456789" aria-label="Chat WhatsApp" className="fixed bottom-5 right-5 z-40 grid size-14 animate-pulse place-items-center rounded-full bg-[#25D366] text-white shadow-xl shadow-[#25D366]/30 transition-transform hover:scale-110"><MessageCircle className="size-7 fill-current" /></a>
  </div>
}

function CalendarIcon() { return <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><rect x="3" y="4" width="18" height="17" rx="3"/><path d="M16 2v4M8 2v4M3 10h18"/></svg> }

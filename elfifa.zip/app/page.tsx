import ElfifaLanding from '@/components/elfifa-landing'

export default function Page() {
  return <ElfifaLanding />
}
